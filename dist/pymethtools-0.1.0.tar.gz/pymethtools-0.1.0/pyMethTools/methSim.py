import numpy as np
from scipy.optimize import minimize,Bounds
from scipy.stats import betabinom
from scipy.special import gammaln,binom,beta
from itertools import chain
import math
import ray
from ray.util.multiprocessing.pool import Pool
import matplotlib.pyplot as plt
import seaborn as sns

np.random.seed(10)

def sim_multiple_cpgs(fits, read_depth=30, adjust_factor=0, ncpu=1, chunksize=1):
    if ncpu > 1: #Use ray for parallel processing
        ray.init(num_cpus=ncpu)
        sims = ray.get([sim_chunk.remote(fits[chunk:chunk+chunksize], adjust_factor=adjust_factor, read_depth=read_depth) for chunk in range(0,len(fits)+1,chunksize)])
        ray.shutdown()
    else:
        sims = [sim(fit, adjust_factor=adjust_factor, read_depth=read_depth) for fit in fits]
    return sims

@ray.remote
def sim_chunk(fits, read_depth=30, adjust_factor=0, sample_size=100):
    chunk_result = [sim(fit, adjust_factor=adjust_factor, read_depth=read_depth) for fit in fits]
    return chunk_result
    
def sim(fit, read_depth=30, adjust_factor=0, sample_size=100):
    return betabinom.rvs(read_depth,fit.x[0]+(adjust_factor*fit.x[0]), fit.x[1], size=sample_size