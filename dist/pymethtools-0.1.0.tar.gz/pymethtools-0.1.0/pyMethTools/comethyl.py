import numpy as np
from scipy.optimize import minimize,Bounds
from scipy.stats import betabinom
from scipy.special import gammaln,binom,beta
import polars as pl
import pandas as pd
from itertools import chain
from functools import partial
import math
import ray
from ray.util.multiprocessing.pool import Pool
import matplotlib.pyplot as plt
import seaborn as sns

np.random.seed(10)

def find_comethyl_regions(fits,meth,coverage,target_regions,min_cpgs=3,ncpu=1,chunksize=1,maxiter=250,maxfev=250):
    
    individual_regions=set(target_regions)
    
    if ncpu > 1: #Use ray for parallel processing
        ray.init(num_cpus=ncpu)    
        fits_id=ray.put(fits)
        meth_id=ray.put(meth)
        coverage_id=ray.put(coverage)
        region_id=ray.put(target_regions)
        if chunksize>1:
            regions = ray.get([comethyl_regions_chunk.remote(individual_regions[chunk:chunk+chunksize],
                                                     fits[np.isin(target_regions,individual_regions[chunk:chunk+chunksize])],
                                                            meth_id,coverage_id,region_id,min_cpgs,
                                                            maxiter,maxfev) 
                          for chunk in range(0,len(set(individual_regions))+1,chunksize)])
            regions = list(chain.from_iterable(result))
        else:
            regions = ray.get([comethyl_regions.remote(region,fits[target_regions==region],meth_id,coverage_id,region_id,min_cpgs,
                                                      maxiter,maxfev) 
                          for region in individual_regions])
        ray.shutdown()

    else:
        regions = [comethyl_regions_local(region,fits[target_regions==region],meth[target_regions==region],
                                          coverage[target_regions==region],
                  regions[target_regions==region],min_cpgs,maxiter,maxfev,local=True) 
                   for region in individual_regions]

    return regions

@ray.remote
def comethyl_regions_chunk(chunk_regions,fits,meth_id,coverage_id,region_id,min_cpgs=3,maxiter=250,maxfev=250):
    individual_regions=set(chunk_regions)
    chunk_result = [comethyl_regions_local(region,fits[region_id==region],meth_id,coverage_id,region_id,min_cpgs,maxiter,maxfev) 
                    for region in individual_regions]
    return chunk_result

def comethyl_regions_local(region,fits,meth_id,coverage_id,region_id,min_cpgs=3,maxiter=250,maxfev=250,local=False):
    
    if local:
        fits=fits_id
        meth=meth_id
        coverage=coverage_id
    else:
        meth=meth_id[region_id==region]
        coverage=coverage_id[region_id==region]
        
    start=0
    end=2
    fit1=fits[0]
    regions=[]
    ll_1 = betabinom.logpmf(meth[0,:],coverage[0,:],fit1.x[0],fit1.x[1]).sum()
    
    while end < meth.shape[0]+1:
        coord = np.s_[start:end] # Combined region to be tested
        
        combined = fit_betabinom_cpg(meth[coord,:].flatten(),coverage[coord,:].flatten(),[fit1.x[0],fit1.x[1]],maxiter,maxfev)
        ll_c = betabinom.logpmf(meth[coord,:].flatten(),coverage[coord,:].flatten(),combined.x[0],combined.x[1]).sum()
        ll_2 = betabinom.logpmf(meth[end-1,:],coverage[end-1,:],fits[end-1].x[0],fits[end-1].x[1]).sum()

        bic_c = 3*math.log((end-start)*meth.shape[1]) - 2*ll_c
        bic_s = 6*math.log((end-start)*meth.shape[1]) - 2*(ll_1+ll_2)
        end += 1

        #If sites come from the same distribution, keep extending the region
        if bic_c < bic_s:
            fit1=combined
            ll_1=ll_c
            previous_coord=coord
        else: # Else start a new region
            if (end-start) > min_cpgs+1: #Save region if number of cpgs > min_cpgs
                regions.append(previous_coord)
            start=end-2
            ll_1=ll_2

    if (end-start) > min_cpgs+1: #Save final region if number of cpgs > min_cpgs
        regions.append(previous_coord)

    return (region, regions)

@ray.remote
def comethyl_regions(region,fits,meth_id,coverage_id,region_id,min_cpgs=3,maxiter=250,maxfev=250):
    meth=meth_id[region_id==region]
    coverage=coverage_id[region_id==region]
    start=0
    end=2
    fit1=fits[0]
    regions=[]
    ll_1 = betabinom.logpmf(meth[0,:],coverage[0,:],fit1.x[0],fit1.x[1]).sum()
    
    while end < meth.shape[0]+1:
        coord = np.s_[start:end] # Combined region to be tested
        
        combined = fit_betabinom_cpg(meth[coord,:].flatten(),coverage[coord,:].flatten(),[fit1.x[0],fit1.x[1]],maxiter,maxfev)
        ll_c = betabinom.logpmf(meth[coord,:].flatten(),coverage[coord,:].flatten(),combined.x[0],combined.x[1]).sum()
        ll_2 = betabinom.logpmf(meth[end-1,:],coverage[end-1,:],fits[end-1].x[0],fits[end-1].x[1]).sum()

        bic_c = 3*math.log((end-start)*meth.shape[1]) - 2*ll_c
        bic_s = 6*math.log((end-start)*meth.shape[1]) - 2*(ll_1+ll_2)
        end += 1

        #If sites come from the same distribution, keep extending the region
        if bic_c < bic_s:
            fit1=combined
            ll_1=ll_c
            previous_coord=coord
        else: # Else start a new region
            if (end-start) > min_cpgs+1: #Save region if number of cpgs > min_cpgs
                regions.append(previous_coord)
            start=end-2
            ll_1=ll_2

    if (end-start) > min_cpgs+1: #Save final region if number of cpgs > min_cpgs
        regions.append(previous_coord)

    return (region, regions)

def region_plot(region_num, beta_vals, cometh, cpg_pos=None):
    region = [x for x in cometh if x[0] == region_num]
    region_plot = pd.DataFrame(beta_vals[regions==region[0][0]])
    if isinstance(cpg_pos, pd.DataFrame):
        region_plot["CpG"] = cpg_pos.loc[cpg_pos["regionID"]==region[0][0], "start"].values
        xlab = "Genomic Position"
    else:
        region_plot["CpG"] = range(0,region_plot.shape[0])
        xlab = "CpG Number in Region"
    
    region_plot["region"] = None
    region_colours=["lightgrey","#5bd7f0", "lightgreen","#f0e15b", "#f0995b", "#db6b6b", "#cd5bf0"]
    for num,region_slice in enumerate(region[0][1]):
        region_plot.loc[region_slice,"region"] = region_colours[num]
        if region_plot[region_slice].tail(1).index != region_plot.tail(1).index: #Slice includes an extra row with .loc 
            region_plot.loc[region_plot.loc[region_slice].tail(1).index,"region"] = None
    region_plot=pd.melt(region_plot, id_vars=["CpG","region"],value_name='Beta Value')
    
    ax = sns.lineplot(region_plot, x="CpG", y="Beta Value")
    ranges = region_plot.groupby('region')['CpG'].agg(['min', 'max'])
    for i, row in ranges.iterrows():
        ax.axvspan(xmin=row['min'], xmax=row['max'], facecolor=i, alpha=0.3)
    region_plot.loc[region_plot["region"].isna(),"region"] = "#4a4a4d"
    sns.scatterplot(region_plot, x="CpG", y=means, c=region_plot.drop_duplicates("CpG")["region"], ax=ax)
    ax.set_title(f"Comethylated Regions in Twist Region {region_num}")
    plt.xlabel(xlab)
    
    
# minimize negative log likelihood
# def bbll(params,k,n):
#     a,b=params
#     ll = binom(n, k) * (beta(k+a, n-k+b) / beta(a, b))
#     return -ll.sum()
