import numpy as np
from scipy.optimize import minimize,Bounds
from scipy.stats import betabinom
from scipy.special import gammaln,binom,beta
import polars as pl
import pandas as pd
from itertools import chain
from functools import partial
import math
import ray
from ray.util.multiprocessing.pool import Pool
import matplotlib.pyplot as plt
import seaborn as sns

np.random.seed(10)

def fit_betabinom(meth, coverage, target_regions,chunksize=1,ncpu=1,maxiter=250,maxfev=250):

    individual_regions=list(set(target_regions))
    
    if ncpu > 1: #Use ray for parallel processing
        ray.init(num_cpus=ncpu)    
        meth_id=ray.put(meth)
        coverage_id=ray.put(coverage)
        region_id=ray.put(target_regions)
        if chunksize>1:
            result = ray.get([fit_betabinom_chunk.remote(individual_regions[chunk:chunk+chunksize],
                                                     meth_id,coverage_id,region_id,maxiter,maxfev) 
                          for chunk in range(0,len(set(individual_regions))+1,chunksize)])
            result = list(chain.from_iterable(result))
        else:
            result = ray.get([fit_betabinom_region.remote(region,meth_id,coverage_id,region_id,maxiter,maxfev) 
                          for region in individual_regions])
        ray.shutdown()
        
    else:
        result = [fit_betabinom_region(meth,coverage,maxiter,maxfev) for region_slice in region_slices]
        
    result = list(chain.from_iterable(result))
        
    return result

@ray.remote
def fit_betabinom_chunk(chunk_regions,meth_id,coverage_id,region_id,maxiter=250,maxfev=250):
    individual_regions=set(chunk_regions)
    chunk_result = [fit_betabinom_region_local(region,meth_id,coverage_id,region_id,maxiter,maxfev) 
                    for region in individual_regions]
    return chunk_result

def fit_betabinom_region_local(region,meth_id,coverage_id,region_id,maxiter=250,maxfev=250):
    region_meth=meth_id[region_id==region]
    region_coverage=coverage_id[region_id==region]

    #Get priors based on region average
    region_prior=fit_betabinom_cpg(region_meth.mean(axis=0),region_coverage.mean(axis=0),[15,30],maxiter,maxfev).x
    inits=[region_prior[0],region_prior[1]]

    region_fits = [fit_betabinom_cpg(region_meth[cpg,:],region_coverage[cpg,:],inits,maxiter,maxfev) for cpg in range(region_meth.shape[0])]

    return region_fits

@ray.remote
def fit_betabinom_region(region,meth_id,coverage_id,region_id,maxiter=250,maxfev=250):
    region_meth=meth_id[region_id==region]
    region_coverage=coverage_id[region_id==region]

    #Get priors based on region average
    region_prior=fit_betabinom_cpg(region_meth.mean(axis=0),region_coverage.mean(axis=0),[15,30],maxiter,maxfev).x
    inits=[region_prior[0],region_prior[1]]

    region_fits = [fit_betabinom_cpg(region_meth[cpg,:],region_coverage[cpg,:],inits,maxiter,maxfev) for cpg in range(region_meth.shape[0])]

    return region_fits

def fit_betabinom_cpg(cpg_meth, cpg_coverage, inits,maxiter=250,maxfev=250):
    return minimize(bbll,inits,args=(cpg_meth,cpg_coverage),method='Nelder-Mead',options={"maxiter":maxiter,"maxfev":maxfev},bounds=Bounds(0,np.inf))

    # minimize negative log likelihood
def bbll(params,k,n):
    init_alpha,init_beta=params
    ll = betabinom.logpmf(k,n,init_alpha,init_beta)
    return -ll.sum()