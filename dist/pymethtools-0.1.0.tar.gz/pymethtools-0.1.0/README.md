# PyMethTools

A package of tools utilising the beta binomial distribution, designed for analysis of targeted DNA methylation sequencing data (e.g. RRBS, Twist Biosciences) in Python. Although, this package can be applied to any methylation data which provides the number of total DNA molecules assayed at a specific position (coverage), and the number of times that position was found to be methylated.

Functions include:
- Finding comethylated regions, by testing if contigous genomic sites are likely to come from one (comethylated) or multiple beta binomial distributions.
- Simulating new samples, using beta binomial distributions fit to existing samples. Set number of differentially methylated sites or regions can be introduced at desired effect sizes, to facilitate tool benchmarking.
- Differential methylation analysis of individual sites or comethylated regions, while accounting for any covariates, using beta binomial regression.
- Celltype deconvolution, using the average beta values of genomic regions hypomethylated in specific celltypes.
- Training of beta binomial regression models to predict continous and categorical traits from DNA methylation profiles, in conjunction with scikitlearn.
