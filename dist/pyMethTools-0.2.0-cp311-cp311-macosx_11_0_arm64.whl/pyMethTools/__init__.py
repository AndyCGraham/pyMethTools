"""
pyMethTools.

An python package for analysis of targetted DNA methylation sequencing data.
"""

__version__ = "0.1.0"
__author__ = 'Andy Graham'